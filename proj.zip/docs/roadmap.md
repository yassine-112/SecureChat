### We will use a spiral dev approach
 - Setup the project envirenement (github repo, build systems and dependencies)
 - alpha app version: serve the web app and a tox echo bot in separate threads
 - add an event loop, initial web app backend event loop handlers
 - work on the tox part and connect it to the event loop
 - finish connecting the web app with its backend and the back end with its event loop
