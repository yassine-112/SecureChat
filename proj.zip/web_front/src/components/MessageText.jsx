export default function MessageText({text}) {
    //TODO: implement the more thing
    return (
        <p style={{color:'white'}}>{text}</p>
    );
}
