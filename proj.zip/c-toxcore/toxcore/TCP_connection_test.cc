#include "TCP_connection.h"

#include <gtest/gtest.h>

namespace {

// TODO(Jfreegman) make this useful or remove it after NGC is merged
TEST(TCP_connection, NullTest) { (void)tcp_send_oob_packet_using_relay; }

}  // namespace
