// Dummy, actual one is here: https://github.com/ralight/mallocfail/blob/master/src/mallocfail.h

int should_malloc_fail(void);
