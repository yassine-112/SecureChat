#include <stdio.h>

// Bootstrap main. Only writes hello world. See ../main/ for the real thing.
extern "C" void app_main(void) { printf("Hello world!\n"); }
