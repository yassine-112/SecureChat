#include "main/tox_main.h"

int main() { tox_main(); }
