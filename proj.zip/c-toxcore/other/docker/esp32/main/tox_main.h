#ifndef TOX_MAIN_H
#define TOX_MAIN_H

void tox_main();

#endif // TOX_MAIN_H
